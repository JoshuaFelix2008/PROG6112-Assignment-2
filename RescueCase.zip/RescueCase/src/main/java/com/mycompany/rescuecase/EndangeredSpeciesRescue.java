/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rescuecase;

/**
 *
 * @author joshu
 */
// This class adds extera info for endangered species rescues.
public class EndangeredSpeciesRescue extends RescueCase {
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;
    
    // Makes a new endangered species rescue case
     public EndangeredSpeciesRescue(String caseID, String animalName, String species, String rescueLocation,
                                   String assignedRanger, int rescueDays, double dailyCareCost, String rescueStatus,
                                   String conservationClassification, double securityCost, boolean specialistTeamRequired) {
        // Call parent constructor (RescueCase)
        super(caseID, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost, rescueStatus);
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }
     
     // Work out total cost (includes security cost + specialist team if needed)
     @Override
     public double calculateTotalCost() {
         double total = super.calculateTotalCost() + securityCost;
         if (specialistTeamRequired) {
             total += 8000; // add R5000 if specialist team is needed.
         }
         return total;
     }
     
     // show all info
     @Override
     public void displayInfo() {
        super.displayInfo(); // show normal rescue info
        System.out.println("Conservation Classification: " + conservationClassification);
        System.out.println("Security Cost: R" + securityCost);
        System.out.println("Specialist Team Required: " + (specialistTeamRequired ? "Yes" : "No"));
        System.out.println("-----------------------------------");
    }
     
     @Override
     public String determineRescuePriority() {
         return "Critical"; // Endangered species are top priority
     }
}
