/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rescuecase;

/**
 *
 * @author joshu
 */
// Class adds extra infor for injurdd animals
public class InjuredAnimalRescue extends RescueCase{
    private String injuryDescription;
    private double vetTreatmentCost;
    private boolean surgeryRequired;
    
    // New injured animal rescue case
    public InjuredAnimalRescue(String caseID, String animalName, String species, String rescueLocation,
                               String assignedRanger, int rescueDays, double dailyCareCost, String rescueStatus,
                               String injuryDescription, double vetTreatmentCost, boolean surgeryRequired) {
        // Call parent constructor (RescueCase)
        super(caseID, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost, rescueStatus);
        this.injuryDescription = injuryDescription;
        this.vetTreatmentCost = vetTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }
    
    // Work out total cost(which includes vet cost + surgey if needed)
    @Override
    public double calculateTotalCost() {
        double total = super.calculateTotalCost() + vetTreatmentCost;
        if (surgeryRequired) {
            total += 5000; //add R5000 if surgery is required
        }
        return total;
    }
    
    // show all info
    @Override
    public void displayInfo() {
        super.displayInfo(); // show normal rescue info
        System.out.println("Injury Description: " + injuryDescription);
        System.out.println("Vet Treatment Cost: R" + vetTreatmentCost);
        System.out.println("Surgery Required: " + (surgeryRequired ? "Yes" : "No"));
        System.out.println("-----------------------------------");
    }
    
    @Override
    public String determineRescuePriority() {
        return "Medium"; // Injured animals need quick but not emergency level attention
    }
}
