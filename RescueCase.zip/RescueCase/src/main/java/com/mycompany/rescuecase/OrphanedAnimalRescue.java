/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rescuecase;

/**
 *
 * @author joshu
 */
// Extra info for orphaned animals
public class OrphanedAnimalRescue extends RescueCase {
    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;
    
    // Makes new orphaned animal rescue case
    public OrphanedAnimalRescue(String caseID, String animalName, String species, String rescueLocation,
                                String assignedRanger, int rescueDays, double dailyCareCost, String rescueStatus,
                                int estimatedAgeMonths, double feedingCost, boolean fosterCareRequired) {
        // Call parent constructor (RescueCase)
        super(caseID, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost, rescueStatus);
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired; 
    }
    
    // Work out total cost( includes feeding cost + foster care if needed)
    @Override
    public double calculateTotalCost() {
        double total = super.calculateTotalCost() + feedingCost;
        if (fosterCareRequired) {
            total += 2500; // add R2500 if foster care is needed
        } 
        return total;
    }
    
    // show all info
    @Override
    public void displayInfo() {
        super.displayInfo(); // show normal rescue info
        System.out.println("Estimated Age (Months): " + estimatedAgeMonths);
        System.out.println("Feeding Cost: R" + feedingCost);
        System.out.println("Foster Care Required: " + (fosterCareRequired ? "Yes" : "No"));
        System.out.println("-----------------------------------");
    }
    
    @Override
    public String determineRescuePriority() {
        return "High"; // Orphaned animals require constant care and feeding
    }
}
