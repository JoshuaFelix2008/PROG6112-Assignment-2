/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.rescuecase;

/**
 *
 * @author joshu
 */
// This class keeps info about one rescue case
public class RescueCase {
    private String caseID;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int rescueDays;
    private double dailyCareCost;
    private String rescueStatus;

    // Makes a new rescue case with all details
    public RescueCase(String caseID, String animalName, String species, String rescueLocation,
                      String assignedRanger, int rescueDays, double dailyCareCost, String rescueStatus) {
        this.caseID = caseID;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.rescueStatus = rescueStatus;
    }

    // Get info
    public String getCaseID() { return caseID; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getRescueLocation() { return rescueLocation; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getRescueDays() { return rescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public String getRescueStatus() { return rescueStatus; }

    // Change rescue status
    public void setRescueStatus(String rescueStatus) {
        this.rescueStatus = rescueStatus;
    }

    // Work out total cost
    public double calculateTotalCost() {
        return rescueDays * dailyCareCost;
    }

    // Show all info
    public void displayInfo() {
        System.out.println("Case ID: " + caseID);
        System.out.println("Animal Name: " + animalName);
        System.out.println("Species: " + species);
        System.out.println("Rescue Location: " + rescueLocation);
        System.out.println("Assigned Ranger: " + assignedRanger);
        System.out.println("Rescue Days: " + rescueDays);
        System.out.println("Daily Care Cost: R" + dailyCareCost);
        System.out.println("Current Status: " + rescueStatus);
        System.out.println("Total Cost: R" + calculateTotalCost());
        System.out.println("-----------------------------------");
    }
    
    // Start rescue operation
    public void startRescueOperation() {
        rescueStatus = "In Progress";
        System.out.println("Rescue operation started for case ID: " + caseID);
    }
    
    // Complete a rescue operation
    public void completeRescueOperation() {
        rescueStatus = "Completed";
        System.out.println("Rescue operation completed for Case ID: " + caseID);
    }
    
    // Determine rescue priority (can be overridden by subclasses)
    public String determineRescuePriority() {
        return "Normal"; // Default priority for standard class
    }
    
    // Generate a rescue summary
    public void generateRescueSummary() {
        System.out.println("===========================================");
        System.out.println("Rescue Summary");
        System.out.println("===========================================");
        System.out.println("Rescue Case ID: " + caseID);
        System.out.println("Rescue Type: " + this.getClass().getSimpleName());
        System.out.println("Species: " + species);
        System.out.println("Assigned Ranger: " + assignedRanger);
        System.out.println("Rescue Priority: " + determineRescuePriority());
        System.out.println("Current Status: " + rescueStatus);
        System.out.println("Total Rescue Cost: R" + calculateTotalCost());
        System.out.println("-------------------------------------------");
    }
}
