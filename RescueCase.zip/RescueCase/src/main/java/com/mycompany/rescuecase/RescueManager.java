/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rescuecase;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author joshu
 */
// This class runs the menu and manages rescue cases.
public class RescueManager {
    private ArrayList<RescueCase> rescueCases = new ArrayList<>();
    private Scanner input = new Scanner(System.in);
    
    // Start program
    public static void main(String[] args) {
        RescueManager manager = new RescueManager();
        manager.runMenu();
    }
    
    // Display menu and handle choices
    public void runMenu() {
        int choice = 0;
        
        while (choice != 9) {
            System.out.println("===========================================");
            System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
            System.out.println("===========================================");
            System.out.println("1. Create Rescue Case");
            System.out.println("2. Search Rescue Case");
            System.out.println("3. Update Rescue Status");
            System.out.println("4. Display All Rescue Cases");
            System.out.println("5. Rescue Report");
            System.out.println("6. Start Rescue Operation");
            System.out.println("7. Complete Rescue Operation");
            System.out.println("8. Generate Rescue Summary");
            System.out.println("9. Exit");
            System.out.print("\nSelect an option: ");
            
            choice = input.nextInt();
            input.nextLine();
            
            switch (choice) {
                case 1:
                    createRescueCase();
                    break;
                case 2:
                    searchRescueCase();
                    break;
                case 3:
                    updateRescueStatus();
                    break;
                case 4:
                    displayAllRescueCases();
                    break;
                case 5:
                    generateRescueReport();
                    break;
                case 6:
                    startRescue();
                    break;
                case 7:
                    completeRescue();
                    break;
                case 8:
                    generateSummary();
                    break;
                case 9:
                    System.out.println("Exiting programming. . . Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Try again.\n");
            }
        }
    }
    
    // Option 1: Add new rescue case
    private void createRescueCase() {
        System.out.println("Select Rescue Type:");
        System.out.println("1. Normal Rescue Case");
        System.out.println("2. Injured Animal Rescue");
        System.out.println("3. Orphaned Animal Rescue");
        System.out.println("4. Endangered Species Rescue");
        System.out.print("Enter choice: ");
        int typeChoice = input.nextInt();
        input.nextLine(); // clear newline
        
       //Common info for all rescue cases
        System.out.print("Enter Case ID: ");
        String id = input.nextLine().trim();
        while (id.isEmpty() || isDuplicateID(id)) {
            if (id.isEmpty()) {
                System.out.print("Case ID cannot be blank. Enter again: ");
            } else {
                System.out.print("Case ID already exists. Enter a unique ID: ");
            }
            id = input.nextLine().trim();
        }
        
        System.out.print("Enter Animal Name: ");
        String name = input.nextLine();
        while (name.isEmpty()) {
            System.out.print("Animal Name cannot be blank. Enter again: ");
            name = input.nextLine().trim();
        }
        
        System.out.print("Enter Species: ");
        String species = input.nextLine().trim();
        while (species.isEmpty()) {
            System.out.print("Rescue Location cannot be blank. Enter again: ");
            species = input.nextLine().trim();
        }
        
        System.out.print("Enter Rescue Location: ");
        String location = input.nextLine().trim();
        while (location.isEmpty()) {
            System.out.print("Rescue Location cannot be blank. Enter again: ");
            location = input.nextLine().trim();
        }
        
        System.out.print("Enter Assigned Ranger: ");
        String ranger = input.nextLine().trim();
        while (location.isEmpty()) {
            System.out.print("Rescue Location cannot be blank. Enter again: ");
            location = input.nextLine().trim();
        }
        
        System.out.print("Enter Number of Rescue Days: ");
        int days = input.nextInt();
        while (days <= 0) {
            System.out.print("Rescue Days must be greater than 0. Enter again: ");
            days = input.nextInt();
        }
        
        System.out.print("Enter Daily Care Cost: ");
        double cost = input.nextDouble();
        while (cost <= 0) {
            System.out.print("Daily Care Cost must be greater than 0. Enter again: ");
            cost = input.nextDouble();
        }
        input.nextLine(); // clear newline
        System.out.print("Enter Rescue Status: ");
        String status = input.nextLine();
        
        RescueCase newCase = null;
        
        // Handle each rescue type
        switch (typeChoice) {
            case 1:
                newCase = new RescueCase(id, name, species, location, ranger, days, cost, status);
                break;
                
            case 2:
                System.out.print("Enter Injury Description: ");
                String injury = input.nextLine();
                System.out.print("Enter Veterinary Treatment Cost: ");
                double vetCost = input.nextDouble();
                input.nextLine();
                System.out.print("Is Surgery Required? (true/false): ");
                boolean surgery = input.nextBoolean();
                input.nextLine();
                newCase = new InjuredAnimalRescue(id, name, species, location, ranger, days, cost, status,
                                                  injury, vetCost, surgery);
                break;
                
            case 3:
                System.out.print("Enter Estimated Age (Months): ");
                int age = input.nextInt();
                System.out.print("Enter Feeding Cost: ");
                double feedCost = input.nextDouble();
                input.nextLine();
                System.out.print("Is Foster Care Required? (true/false): ");
                boolean foster = input.nextBoolean();
                input.nextLine();
                newCase = new OrphanedAnimalRescue(id, name, species, location, ranger, days, cost, status,
                                                   age, feedCost, foster);
                break;
                
            case 4:
                System.out.print("Enter Conservation Classification: ");
                String classification = input.nextLine();
                System.out.print("Enter Security Cost: ");
                double security = input.nextDouble();
                input.nextLine();
                System.out.print("Is Specialist Team Required? (true/false): ");
                boolean specialist = input.nextBoolean();
                input.nextLine();
                newCase = new EndangeredSpeciesRescue(id, name, species, location, ranger, days, cost, status,
                                                      classification, security, specialist);
                break;
                
            default:
                System.out.println("Invalid rescue type selected.");
                return;     
        }
        
        rescueCases.add(newCase);
        System.out.println("Rescue case added successfully!\n");
    }
    
    // Option 2: Search rescue case by ID
    private void searchRescueCase() {
        System.out.print("Enter Case ID to search: ");
        String id = input.nextLine();
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseID().equalsIgnoreCase(id)) {
                rc.displayInfo();
                return;
            }
        }
        System.out.println("Rescue case not found.\n");
    }
    
    // Option 3: Updatre rescue status
    private void updateRescueStatus() {
        System.out.println("Enter Case ID to update: ");
        String id = input.nextLine();
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseID().equalsIgnoreCase(id)) {
                System.out.print("Eanter new rescue status: ");
                String newStatus = input.nextLine();
                rc.setRescueStatus(newStatus);
                System.out.println("Rescue status updated!\n");
                return;
            }
        }
        System.out.println("Rescue case not found.\n");
    }
    
    // Option 4: Show all rescue cases
    private void displayAllRescueCases() {
        if(rescueCases.isEmpty()) {
            System.out.println("No rescue cases found.\n");
        } else {
            for (RescueCase rc : rescueCases) {
                rc.displayInfo();
            }
        }
    }
    
    // Option 5: show total report
    private void generateRescueReport() {
        if (rescueCases.isEmpty()) {
            System.out.println("No rescuse cases found.\n");
            return;
        }
        
        double totalCost = 0;
        int totalCases = rescueCases.size();
        
        System.out.println("=========================================================");
        System.out.println("WILDLIFE RESCUE REPORT:");
        System.out.println("=========================================================");
        
        for (RescueCase rc : rescueCases) {
            System.out.println("Case ID          : " + rc.getCaseID());
            System.out.println("Type             : " + rc.getClass().getSimpleName());
            System.out.println("Species          : " + rc.getSpecies());
            System.out.println("Rescue Location  : " + rc.getRescueLocation());
            System.out.println("Assigned Ranger  : " + rc.getAssignedRanger());
            System.out.println("Priority         : " + rc.determineRescuePriority());
            System.out.println("Status           : " + rc.getRescueStatus());
            System.out.println("Total Cost       : R" + rc.calculateTotalCost());
            System.out.println("---------------------------------------------------------");
            
            totalCost += rc.calculateTotalCost();
        }
        
         System.out.println("Total Rescue Cases : " + totalCases);
         System.out.println("Total Rescue Cost  : R" + totalCost);
         System.out.println("=========================================================\n");
    }
    
    private void startRescue() {
        System.out.print("Enter Case ID to start: ");
        String id = input.nextLine();
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseID().equalsIgnoreCase(id)) {
                rc.startRescueOperation();
                return;
            }
        }
        System.out.println("Rescue case not found.\n");
    }
    
    private void completeRescue() {
        System.out.print("Enter Case ID to complete: ");
        String id = input.nextLine();
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseID().equalsIgnoreCase(id)) {
                rc.completeRescueOperation();
                return;
            }
        }
        System.out.println("Rescue case not found.\n");
    }
    
    private void generateSummary() {
        System.out.print("Enter Case ID to summarize: ");
        String id = input.nextLine();
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseID().equalsIgnoreCase(id)) {
                rc.generateRescueSummary();
                return;
            }
        }
        System.out.println("Rescus case not found.\n");
    }
    
    // Checks if a rescue case ID already exists
    public boolean isDuplicateID(String id) {
        for (RescueCase rc: rescueCases) {
            if (rc.getCaseID().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }
    
    public void addRescueCase(RescueCase rc) {
        rescueCases.add(rc);
    }
    
    public ArrayList<RescueCase> getRescueCases() {
        return rescueCases;
    }
}
