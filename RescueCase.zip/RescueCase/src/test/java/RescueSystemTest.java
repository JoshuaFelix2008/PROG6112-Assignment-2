/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.rescuecase.RescueCase;
import com.mycompany.rescuecase.RescueManager;
import com.mycompany.rescuecase.InjuredAnimalRescue;
import com.mycompany.rescuecase.OrphanedAnimalRescue;
import com.mycompany.rescuecase.EndangeredSpeciesRescue;

public class RescueSystemTest {

    // Test Rescue cost calculations (Copilot assisted with created unit tests
    @Test
    void testCalculateTotalCost() {
        RescueCase rc = new RescueCase("R001", "Elephant", "African Elephant",
                "Kruger Park", "Ranger Sipho", 10, 500, "In Progress");
        assertEquals(5000, rc.calculateTotalCost(), "Total cost should equal days × daily cost");
    }

    // 2️⃣ Test Rescue Priority (Subclass Overrides)
    @Test
    void testPriorityLevels() {
        InjuredAnimalRescue injured = new InjuredAnimalRescue("I001", "Elephant", "African Elephant",
                "Kruger Park", "Ranger Sipho", 10, 500, "In Progress",
                "Broken tusk", 3000, true);
        OrphanedAnimalRescue orphaned = new OrphanedAnimalRescue("O001", "Lion Cub", "Panthera Leo",
                "Serengeti", "Ranger Sarah", 8, 400, "In Shelter",
                6, 1200, true);
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue("E001", "Rhino", "Black Rhino",
                "Hluhluwe-Imfolozi", "Ranger Thabo", 15, 800, "Under Protection",
                "Critically Endangered", 2000, true);

        assertEquals("Medium", injured.determineRescuePriority());
        assertEquals("High", orphaned.determineRescuePriority());
        assertEquals("Critical", endangered.determineRescuePriority());
    }

    // 3️⃣ Test Rescue Status Updates
    @Test
    void testRescueStatusUpdates() {
        RescueCase rc = new RescueCase("R002", "Zebra", "Plains Zebra",
                "Addo Park", "Ranger Lindiwe", 5, 300, "Pending");
        rc.startRescueOperation();
        assertEquals("In Progress", rc.getRescueStatus());
        rc.completeRescueOperation();
        assertEquals("Completed", rc.getRescueStatus());
    }

    // 4️⃣ Test Searching for Existing Rescue Case
    @Test
    void testSearchRescueCase() {
        RescueManager manager = new RescueManager();
        RescueCase rc = new RescueCase("R003", "Buffalo", "Cape Buffalo",
                "Kruger Park", "Ranger Themba", 7, 400, "Pending");
        
        manager.addRescueCase(rc);

        boolean found = manager.getRescueCases().stream()
                .anyMatch(r -> r.getCaseID().equalsIgnoreCase("R003"));
        assertTrue(found, "Rescue case should be found by ID");
    }

    // Test preventing Duplicate ids
    @Test
    void testDuplicateIDPrevention() {
        RescueManager manager = new RescueManager();
        RescueCase rc1 = new RescueCase("R004", "Leopard", "Panthera Pardus",
                "Kruger Park", "Ranger Zanele", 6, 600, "Pending");
        manager.addRescueCase(rc1);

        assertTrue(manager.isDuplicateID("R004"), "Duplicate ID should be detected");
        assertFalse(manager.isDuplicateID("R999"), "Non‑existing ID should not be detected");
    }
}

